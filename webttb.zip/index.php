<!doctype html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <!-- WARNING: for iOS 7, remove the width=device-width and height=device-height attributes. See https://issues.apache.org/jira/browse/CB-4323 -->
    <link rel="stylesheet" href="css/base.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="css/font-awesome.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="css/slider.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="css/mobile.css" type="text/css" media="screen" />
    <title>ToyBox Bali</title>
    <link rel="icon" href="images/tempo-white.ico" />
</head>

<body>
    <nav id="cd-lateral-nav" class="hide_desktop">
        <ul class="cd-navigation">
            <li><a href="index.php" class="current">Beranda</a></li>
            <li><a href="#">Tentang Kami</a></li>
            <li class="item-has-children"><a href="#">Portfolio</a>
                <ul class="sub-menu">
                    <li><a href="#">Pengembangan Website</a></li>
                    <li><a href="#">Pengelolaan Data Online</a></li>
                    <li><a href="#">Multimedia</a></li>
                </ul>
            </li>
            <li class="item-has-children"><a href="#">Layanan</a>
                <ul class="sub-menu">
                    <li class="item-has-children"><a href="#">Literasi Keuangan</a>
                        <ul class="sub-menu">
                            <li><a href="#">Keuanganku</a></li>
                            <li><a href="#">Simpanan</a></li>
                            <li><a href="#">Investasi</a></li>
                            <li><a href="#">Pinjaman</a></li>
                            <li><a href="#">Proteksi</a></li>
                        </ul>
                    </li>
                    <li class="item-has-children"><a href="#">Simulasi Kredit</a>
                        <ul class="sub-menu">
                            <li><a href="#">Kredit Usaha Rakyat</a></li>
                            <li><a href="#">KUPEDES</a></li>
                            <li><a href="#">Kredit Modal Kerja</a></li>
                            <li><a href="#">Kredit Investasi</a></li>
                            <li><a href="#">Kredit Kendaraan Bermotor</a></li>
                            <li><a href="#">Kredit Pemilikan Rumah</a></li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li><a href="#">Hubungi Kami</a></li>
        </ul>
        <div class="padding-left-sm padding-right-sm padding-top-sm padding-bottom-sm">
            <button class="sign-btn bg-red" style="border-radius:4px;" onclick="location.href='login.php'">login</button>
        </div>
    </nav>
    <header class="header fix-header">
        <div class="header-bar">
            <div></div>
            <div class="top-link">
                <a href="#">About Us</a>
                <a href="#" class="cl-pink fw6">Promo</a>
                <a href="#">Extend Rental</a>
                <a href="#">Confirm Payment</a>
                <a href="#">CS <i class="fa fa-whatsapp cl-whatsapp margin-right-ss margin-left-ss"></i>0987654321</a>
            </div>
        </div>
        <div class="header-in">
            <div class="logo"><a href="#"><img src="images/logo.png"></a></div>
            <div class="search-bar">
                <div class="out-form fi-w-auto hide_mobile">
                    <div class="box-form">
                        <select class="input-select radius8">
                            <option value="0">KATEGORI</option>
                            <option value="1">Kategori Satu</option>
                            <option value="2">Kategori Dua</option>
                            <option value="3">Kategori Tiga</option>
                            <option value="4">Kategori Empat</option>
                            <option value="5">Kategori Lima</option>
                        </select>
                    </div>
                </div>
                <div class="out-form w100 fi-right-icon">
                    <div class="box-form">
                        <button class="btn-right bg-clean cl-text"><i class="fa fa-search"></i></button>
                        <input type="text" id="btnright" class="input-text radius8" placeholder="cari produk...">
                    </div>
                </div>
            </div>
            <div class="header-right">
                <button class="square-icon shopping">
                    <div class="qty">1</div><img src="images/icons/shopping_bag.svg">
                </button>
                <button class="square-icon notifications margin-right-lg">
                    <div class="notif"></div><img src="images/icons/notifications.svg">
                </button>
                <a id="cd-menu-trigger" class="fix-header rightpos" href="#0"><span class="cd-menu-icon"></span></a>
                <button class="btn radius8 line-btn blue-btn margin-right-ss hide_mobile">Masuk</button>
                <button class="btn radius8 hide_mobile">Daftar</button>
            </div>
        </div>
    </header>
    <main class="cd-main-content">
        <section class="slider-cover">
            <div class="container">
                <section class="slider slider-utama">
                    <div class="slider-item">
                        <div class="card-box radius8 overflow">
                            <a href="#">
                                <figure class="img-card"><img src="images/slider_utama_01.png"></figure>
                            </a>
                        </div>
                    </div>
                    <div class="slider-item">
                        <div class="card-box radius8 overflow">
                            <a href="#">
                                <figure class="img-card"><img src="images/slider_utama_01.png"></figure>
                            </a>
                        </div>
                    </div>
                </section>
            </div>
        </section>
        <section class="container overflow margin-bottom-lg">
            <div class="grid-clm row4 gap16-all info-box">
                <div class="card-box greenbox">
                    <div class="text-card">
                        <div class="box-avatar xl-avatar">
                            <div class="avatar bg-green cl-white">
                                <img src="images/earnings.png">
                            </div>
                        </div>
                        <div class="text-info">
                            <h4 class="margin-top-sm t-center">Cicilan 0%</h4>
                            <p class="f14 t-center margin-top-xs">Seluruh transaksi dapat dicicil dengan bunga 0% minimum transaksi Rp 500.000</p>
                        </div>
                    </div>
                </div>
                <div class="card-box pinkbox">
                    <div class="text-card">
                        <div class="box-avatar xl-avatar">
                            <div class="avatar bg-pink cl-white">
                                <img src="images/delivery.png">
                            </div>
                        </div>
                        <div class="text-info">
                            <h4 class="margin-top-sm t-center">Jaminan Pengiriman</h4>
                            <p class="f14 t-center margin-top-xs">Apabila barang tidak sampai, uang akan dikembalikan seluruhnya</p>
                        </div>
                    </div>
                </div>
                <div class="card-box bluebox">
                    <div class="text-card">
                        <div class="box-avatar xl-avatar">
                            <div class="avatar bg-blue cl-white">
                                <img src="images/text-editor.png">
                            </div>
                        </div>
                        <div class="text-info">
                            <h4 class="margin-top-sm t-center">Kebijakan Pengembalian</h4>
                            <p class="f14 t-center margin-top-xs">Jika barang yang disewa tidak bersih, refund 100% tanpa ribet.</p>
                        </div>
                    </div>
                </div>
                <div class="card-box yellowbox">
                    <div class="text-card">
                        <div class="box-avatar xl-avatar">
                            <div class="avatar bg-yellow cl-white">
                                <img src="images/like.png">
                            </div>
                        </div>
                        <div class="text-info">
                            <h4 class="margin-top-sm t-center">Kualitas Terjamin</h4>
                            <p class="f14 t-center margin-top-xs">Bersih dan higienis dengan standar kebersihan menggunakan mesin skala industri</p>
                        </div>
                    </div>
                </div>
            </div>
        </section> <!-- end container 1 -->
        <section class="container overflow margin-bottom-lg">
            <div class="grid-clm row4 gap16-all small-banner">
                <div class="grid-clm-2-2">
                    <div class="slider slider-small-banner">
                        <div class="slider-item">
                            <div class="card-box radius8 overflow">
                                <a href="#">
                                    <figure class="img-card"><img src="images/small-banner01.png"></figure>
                                </a>
                            </div>
                        </div>
                        <div class="slider-item">
                            <div class="card-box radius8 overflow">
                                <a href="#">
                                    <figure class="img-card"><img src="images/small-banner01.png"></figure>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-box">
                    <div class="square">
                        <figure class="square-img radius8">
                            <a href="#">
                                <img src="images/square-banner01.png">
                            </a>
                        </figure>
                    </div>
                </div>
                <div class="card-box">
                    <div class="square">
                        <figure class="square-img radius8">
                            <a href="#">
                                <img src="images/square-banner02.png">
                            </a>
                        </figure>
                    </div>
                </div>
            </div>
        </section> <!-- end container 2 -->
        <section class="container full padding-no bg-soft-blue">
            <div class="container padding-no">
                <div class="blockbox padding-top-lg padding-bottom-lg margin-bottom-no">
                    <h2 class="titlebox w-right-btn">
                        Produk Terpopuler
                        <span class="next-page">
                            <a href="#">
                                lihat semua
                                <div class="box-avatar ss-avatar margin-left-ss">
                                    <div class="avatar bg-pink cl-white">
                                        <i class="fa fa-angle-right"></i>
                                    </div>
                                </div>
                            </a>
                        </span>
                    </h2>
                    <section class="slider slider-populer dark-arrow">
                        <div class="slider-item">
                            <div class="card-box line-item">
                                <a href="#">
                                    <div class="square">
                                        <div class="square-img">
                                            <img src="images/produk06.jpg">
                                        </div>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                        <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="slider-item">
                            <div class="card-box line-item">
                                <a href="#">
                                    <div class="square">
                                        <div class="square-img">
                                            <img src="images/produk04.jpg">
                                        </div>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                        <h6 class="fw4 line1 coret cl-dark-gray">Rp. 9.500 /hari</h6>
                                        <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="slider-item">
                            <div class="card-box line-item">
                                <a href="#">
                                    <div class="square">
                                        <div class="square-img">
                                            <img src="images/produk02.jpg">
                                        </div>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                        <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="slider-item">
                            <div class="card-box line-item">
                                <a href="#">
                                    <div class="square">
                                        <div class="square-img">
                                            <img src="images/produk08.jpg">
                                        </div>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                        <h6 class="fw4 line1 coret cl-dark-gray">Rp. 9.500 /hari</h6>
                                        <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="slider-item">
                            <div class="card-box line-item">
                                <a href="#">
                                    <div class="square">
                                        <div class="square-img">
                                            <img src="images/produk09.jpg">
                                        </div>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                        <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="slider-item">
                            <div class="card-box line-item">
                                <a href="#">
                                    <div class="square">
                                        <div class="square-img">
                                            <img src="images/produk07.jpg">
                                        </div>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                        <h6 class="fw4 line1 coret  cl-dark-gray">Rp. 9.500 /hari</h6>
                                        <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </section>
        <section class="container full padding-no">
            <div class="container padding-no">
                <section class="blockbox padding-top-lg padding-bottom-lg margin-bottom-no">
                    <h2 class="titlebox w-right-btn">
                        Update Stock
                        <span class="next-page">
                            <a href="#">
                                lihat semua
                                <div class="box-avatar ss-avatar margin-left-ss">
                                    <div class="avatar bg-pink cl-white">
                                        <i class="fa fa-angle-right"></i>
                                    </div>
                                </div>
                            </a>
                        </span>
                    </h2>
                    <div class="slider slider-stock dark-arrow">
                        <div class="slider-item">
                            <div class="card-box line-item">
                                <a href="#">
                                    <div class="square">
                                        <div class="square-img">
                                            <img src="images/produk07.jpg">
                                        </div>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                        <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="slider-item">
                            <div class="card-box line-item">
                                <a href="#">
                                    <div class="square">
                                        <div class="square-img">
                                            <img src="images/produk08.jpg">
                                        </div>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                        <h6 class="fw4 line1 coret cl-dark-gray">Rp. 9.500 /hari</h6>
                                        <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="slider-item">
                            <div class="card-box line-item">
                                <a href="#">
                                    <div class="square">
                                        <div class="square-img">
                                            <img src="images/produk09.jpg">
                                        </div>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                        <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="slider-item">
                            <div class="card-box line-item">
                                <a href="#">
                                    <div class="square">
                                        <div class="square-img">
                                            <img src="images/produk01.jpg">
                                        </div>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                        <h6 class="fw4 line1 coret cl-dark-gray">Rp. 9.500 /hari</h6>
                                        <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="slider-item">
                            <div class="card-box line-item">
                                <a href="#">
                                    <div class="square">
                                        <div class="square-img">
                                            <img src="images/produk02.jpg">
                                        </div>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                        <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="slider-item">
                            <div class="card-box line-item">
                                <a href="#">
                                    <div class="square">
                                        <div class="square-img">
                                            <img src="images/produk03.jpg">
                                        </div>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                        <h6 class="fw4 line1 coret  cl-dark-gray">Rp. 9.500 /hari</h6>
                                        <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="blockbox padding-top-lg padding-bottom-lg margin-bottom-no">
                    <h2 class="titlebox w-right-btn margin-bottom-sm">
                        Produk Terbaru
                        <span class="next-page">
                            <a href="#">
                                lihat semua
                                <div class="box-avatar ss-avatar margin-left-ss">
                                    <div class="avatar bg-pink cl-white">
                                        <i class="fa fa-angle-right"></i>
                                    </div>
                                </div>
                            </a>
                        </span>
                    </h2>
                    <div class="box-front-kategori margin-bottom-sm">
                        <h3 class="title">Pilih Kategori</h3>
                        <div class="slider slider-kategori">
                            <div class="slider-item">
                                <button class="btn actived">
                                    <img src="images/icons/toys.png" class="margin-right-xs">
                                    Semua Kategori
                                </button>
                            </div>
                            <div class="slider-item">
                                <button class="btn">
                                    <img src="images/icons/cot.png" class="margin-right-xs">
                                    Nursery
                                </button>
                            </div>
                            <div class="slider-item">
                                <button class="btn">
                                    <img src="images/icons/stroller.png" class="margin-right-xs">
                                    Strollers
                                </button>
                            </div>
                            <div class="slider-item">
                                <button class="btn">
                                    <img src="images/icons/carseat.png" class="margin-right-xs">
                                    Car Seats
                                </button>
                            </div>
                            <div class="slider-item">
                                <button class="btn">
                                    <img src="images/icons/crib-toy.png" class="margin-right-xs">
                                    Toys
                                </button>
                            </div>
                            <div class="slider-item">
                                <button class="btn">
                                    <img src="images/icons/gate.png" class="margin-right-xs">
                                    Safety
                                </button>
                            </div>
                            <div class="slider-item">
                                <button class="btn">
                                    <img src="images/icons/apparel.png" class="margin-right-xs">
                                    Affarel
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="grid-clm row5 gap16-all list_terbaru">
                        <div class="card-box line-item">
                            <a href="#">
                                <div class="square">
                                    <div class="square-img">
                                        <img src="images/produk01.jpg">
                                    </div>
                                </div>
                                <div class="text-card">
                                    <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                    <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                </div>
                            </a>
                        </div>
                        <div class="card-box line-item">
                            <a href="#">
                                <div class="square">
                                    <div class="square-img">
                                        <img src="images/produk02.jpg">
                                    </div>
                                </div>
                                <div class="text-card">
                                    <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                    <h6 class="fw4 line1 coret cl-dark-gray">Rp. 9.500 /hari</h6>
                                    <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                </div>
                            </a>
                        </div>
                        <div class="card-box line-item">
                            <a href="#">
                                <div class="square">
                                    <div class="square-img">
                                        <img src="images/produk03.jpg">
                                    </div>
                                </div>
                                <div class="text-card">
                                    <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                    <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                </div>
                            </a>
                        </div>
                        <div class="card-box line-item">
                            <a href="#">
                                <div class="square">
                                    <div class="square-img">
                                        <img src="images/produk04.jpg">
                                    </div>
                                </div>
                                <div class="text-card">
                                    <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                    <h6 class="fw4 line1 coret cl-dark-gray">Rp. 9.500 /hari</h6>
                                    <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                </div>
                            </a>
                        </div>
                        <div class="card-box line-item">
                            <a href="#">
                                <div class="square">
                                    <div class="square-img">
                                        <img src="images/produk05.jpg">
                                    </div>
                                </div>
                                <div class="text-card">
                                    <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                    <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                </div>
                            </a>
                        </div>
                        <div class="card-box line-item">
                            <a href="#">
                                <div class="square">
                                    <div class="square-img">
                                        <img src="images/produk06.jpg">
                                    </div>
                                </div>
                                <div class="text-card">
                                    <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                    <h6 class="fw4 line1 coret  cl-dark-gray">Rp. 9.500 /hari</h6>
                                    <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                </div>
                            </a>
                        </div>
                        <div class="card-box line-item">
                            <a href="#">
                                <div class="square">
                                    <div class="square-img">
                                        <img src="images/produk07.jpg">
                                    </div>
                                </div>
                                <div class="text-card">
                                    <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                    <h6 class="fw4 line1 coret  cl-dark-gray">Rp. 9.500 /hari</h6>
                                    <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                </div>
                            </a>
                        </div>
                        <div class="card-box line-item">
                            <a href="#">
                                <div class="square">
                                    <div class="square-img">
                                        <img src="images/produk08.jpg">
                                    </div>
                                </div>
                                <div class="text-card">
                                    <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                    <h6 class="fw4 line1 coret  cl-dark-gray">Rp. 9.500 /hari</h6>
                                    <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                </div>
                            </a>
                        </div>
                        <div class="card-box line-item">
                            <a href="#">
                                <div class="square">
                                    <div class="square-img">
                                        <img src="images/produk09.jpg">
                                    </div>
                                </div>
                                <div class="text-card">
                                    <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                    <h6 class="fw4 line1 coret  cl-dark-gray">Rp. 9.500 /hari</h6>
                                    <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                </div>
                            </a>
                        </div>
                        <div class="card-box line-item">
                            <a href="#">
                                <div class="square">
                                    <div class="square-img">
                                        <img src="images/produk01.jpg">
                                    </div>
                                </div>
                                <div class="text-card">
                                    <h5 class="fw5 line2 cl-text">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</h5>
                                    <h6 class="fw4 line1 coret  cl-dark-gray">Rp. 9.500 /hari</h6>
                                    <h5 class="cl-blue">Rp. 8.000 /hari</h5>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="centering margin-top-xl">
                        <button class="btn lg-btn radius8 bg-pink cl-white">Lihat Produk Lainnya</button>
                    </div>
                </section>
            </div>
        </section>
        <section class="container full padding-no bg-soft-yellow">
            <div class="container padding-no">
                <section class="blockbox padding-top-lg padding-bottom-lg margin-bottom-no">
                    <h2 class="titlebox w-right-btn">
                        Artikel
                        <span class="next-page">
                            <a href="#">
                                lihat semua
                                <div class="box-avatar ss-avatar margin-left-ss">
                                    <div class="avatar bg-pink cl-white">
                                        <i class="fa fa-angle-right"></i>
                                    </div>
                                </div>
                            </a>
                        </span>
                    </h2>
                    <div class="grid-clm row2 gap24-all list_artikel">
                        <div class="artikel_utama">
                            <div class="card-box">
                                <div class="img-card">
                                    <a href="#"><img src="images/rat169.jpg"></a>
                                </div>
                                <div class="text-card">
                                    <h2 class="fw7 line2 cl-text margin-bottom-xs"><a href="#">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</a>
                                    </h2>
                                    <p class="fo14 margin-bottom-xs line3">I solved the responsive breakpoint issue, recalculating the number of slides at any browser resize.testimonialsList: it's the name of the container of my carousel. I solved the responsive breakpoint issue, recalculating the number of slides at any browser resize.testimonialsList: it's the name of the container of my carousel.</p>
                                    <h6 class="fw4 cl-blue">30 Oktober 2024</h6>
                                </div>
                                </a>
                            </div>
                        </div>
                        <div class="artikel_lainnya">
                            <div class="grid-clm row2 grid-clm-2-2 gap24-all">
                                <div class="card-box">
                                    <div class="img-card">
                                        <a href="#"><img src="images/rat169.jpg"></a>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="line2 cl-text margin-bottom-xs"><a href="#">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</a>
                                        </h5>
                                        <h6 class="fw4 cl-blue">30 Oktober 2024</h6>
                                    </div>
                                    </a>
                                </div>
                                <div class="card-box">
                                    <div class="img-card">
                                        <a href="#"><img src="images/rat169.jpg"></a>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="line2 cl-text margin-bottom-xs"><a href="#">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</a>
                                        </h5>
                                        <h6 class="fw4 cl-blue">30 Oktober 2024</h6>
                                    </div>
                                    </a>
                                </div>
                                <div class="card-box">
                                    <div class="img-card">
                                        <a href="#"><img src="images/rat169.jpg"></a>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="line2 cl-text margin-bottom-xs"><a href="#">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</a>
                                        </h5>
                                        <h6 class="fw4 cl-blue">30 Oktober 2024</h6>
                                    </div>
                                    </a>
                                </div>
                                <div class="card-box">
                                    <div class="img-card">
                                        <a href="#"><img src="images/rat169.jpg"></a>
                                    </div>
                                    <div class="text-card">
                                        <h5 class="line2 cl-text margin-bottom-xs"><a href="#">Anda juga dapat melihat pintasan keyboard default di samping perintah di Command Palette</a>
                                        </h5>
                                        <h6 class="fw4 cl-blue">30 Oktober 2024</h6>
                                    </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </section>
        <section class="container full padding-no bg-soft-green">
            <div class="container padding-no">
                <section class="blockbox padding-top-lg padding-bottom-lg margin-bottom-no">
                    <h2 class="titlebox w-right-btn">
                        Official Brand
                        <span class="next-page">
                            <a href="#">
                                lihat semua
                                <div class="box-avatar ss-avatar margin-left-ss">
                                    <div class="avatar bg-pink cl-white">
                                        <i class="fa fa-angle-right"></i>
                                    </div>
                                </div>
                            </a>
                        </span>
                    </h2>
                    <div class="slider slider-brand dark-arrow">
                        <div class="slider-item">
                            <a href="#">
                                <div class="square line radius8">
                                    <div class="square-img radius8">
                                        <img src="images/brand/logo-babyzen.jpg">
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="slider-item">
                            <a href="#">
                                <div class="square line radius8">
                                    <div class="square-img radius8">
                                        <img src="images/brand/logo-bugaboo.jpg">
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="slider-item">
                            <a href="#">
                                <div class="square line radius8">
                                    <div class="square-img radius8">
                                        <img src="images/brand/logo-fisherprice.jpg">
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="slider-item">
                            <a href="#">
                                <div class="square line radius8">
                                    <div class="square-img radius8">
                                        <img src="images/brand/logo-foldaway.jpg">
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="slider-item">
                            <a href="#">
                                <div class="square line radius8">
                                    <div class="square-img radius8">
                                        <img src="images/brand/logo-joie.jpg">
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="slider-item">
                            <a href="#">
                                <div class="square line radius8">
                                    <div class="square-img radius8">
                                        <img src="images/brand/logo-littletikes.jpg">
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="slider-item">
                            <a href="#">
                                <div class="square line radius8">
                                    <div class="square-img radius8">
                                        <img src="images/brand/logo-nuna.jpg">
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="slider-item">
                            <a href="#">
                                <div class="square line radius8">
                                    <div class="square-img radius8">
                                        <img src="images/brand/logo-summerinfant.jpg">
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="slider-item">
                            <a href="#">
                                <div class="square line radius8">
                                    <div class="square-img radius8">
                                        <img src="images/brand/logo-trunki.jpg">
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="slider-item">
                            <a href="#">
                                <div class="square line radius8">
                                    <div class="square-img radius8">
                                        <img src="images/brand/logo-upang.jpg">
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="slider-item">
                            <a href="#">
                                <div class="square line radius8">
                                    <div class="square-img radius8">
                                        <img src="images/brand/logo-vtech.jpg">
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="slider-item">
                            <a href="#">
                                <div class="square line radius8">
                                    <div class="square-img radius8">
                                        <img src="images/brand/logo-walkingwings.jpg">
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </section>
            </div>
        </section>
    </main>
    <footer class="footer">
        <div class="footer-in">
            <div class="grid6">
                <div class="footer1 bg-soft-pink">
                    <div class="logo-footer"><img src="images/logo.png"></div>
                    <h4 class="cl-text margin-top-xl margin-bottom-sm">Customer Care</h4>
                    <a href="#" class="link margin-bottom-xs margin-top-xs cl-text">
                        <div class="icons margin-right-xs"><img src="images/icons/envelope.png"></div>info@toyboxbali.id
                    </a>
                    <a href="#" class="link margin-bottom-xs margin-top-xs cl-text">
                        <div class="icons margin-right-xs"><img src="images/icons/whatsapp.png"></div>082144256215
                    </a>
                    <a href="#" class="link margin-bottom-xs margin-top-xs cl-text">
                        <div class="icons margin-right-xs"><img src="images/icons/line.png"></div>@Toyboxbali
                    </a>
                    <h4 class="cl-pink margin-top-lg margin-bottom-xs">Operasional Customer</h4>
                    <div>
                        <p class="fo14 cl-pink margin-top-no margin-bottom-xs">Senin - Minggu<br>(09.00 - 17.00 WITA)</p>
                        <p class="fo14 cl-pink margin-no">Kecuali Hari Libur Nasional</p>
                    </div>
                </div>
                <div class="footer2 padding-top-lg padding-bottom-lg">
                    <h4 class="cl-soft-pink margin-bottom-sm">Informasi</h4>
                    <a href="#" class="link">About Us</a>
                    <a href="#" class="link">Extend Rental</a>
                    <a href="#" class="link">Confirm Payment</a>
                    <a href="#" class="link">Shipping</a>
                    <a href="#" class="link">How to Order</a>
                    <a href="#" class="link">Privacy Policy</a>
                    <a href="#" class="link">Term & Condition</a>
                </div>
                <div class="footer3 padding-top-lg padding-bottom-lg">
                    <h4 class="cl-soft-pink margin-bottom-sm">Kategori</h4>
                    <a href="#" class="link">Nursery</a>
                    <a href="#" class="link">Strollers</a>
                    <a href="#" class="link">Car Seats</a>
                    <a href="#" class="link">Toys</a>
                    <a href="#" class="link">Gear</a>
                    <a href="#" class="link">Safety</a>
                    <a href="#" class="link">Apparel</a>
                </div>
                <div class="footer4 padding-top-lg padding-bottom-lg">
                    <h4 class="cl-soft-pink margin-bottom-sm">Metode Pembayaran</h4>
                    <div class="box-pay">
                        <div class="column-pay">
                            <p class="fo14 margin-top-no">Cicilan 0%</p>
                            <div class="box-pay-icon">
                                <div class="icon-pay">
                                    <img src="images/brand/bca.png">
                                </div>
                                <div class="icon-pay">
                                    <img src="images/brand/bri.png">
                                </div>
                                <div class="icon-pay">
                                    <img src="images/brand/mandiri.png">
                                </div>
                                <div class="icon-pay">
                                    <img src="images/brand/bni.png">
                                </div>
                            </div>
                        </div>
                        <div class="column-pay">
                            <p class="fo14 margin-top-no">Bank Transfer</p>
                            <div class="box-pay-icon">
                                <div class="icon-pay">
                                    <img src="images/brand/bca.png">
                                </div>
                                <div class="icon-pay">
                                    <img src="images/brand/bri.png">
                                </div>
                                <div class="icon-pay">
                                    <img src="images/brand/mandiri.png">
                                </div>
                            </div>
                        </div>
                        <div class="column-pay">
                            <p class="fo14 margin-top-no">Credit Card</p>
                            <div class="box-pay-icon">
                                <div class="icon-pay">
                                    <img src="images/brand/visa.png">
                                </div>
                                <div class="icon-pay">
                                    <img src="images/brand/mastercard.png">
                                </div>
                            </div>
                        </div>
                        <div class="column-pay">
                            <p class="fo14 margin-top-no">Virtual Account</p>
                            <div class="box-pay-icon">
                                <div class="icon-pay">
                                    <img src="images/brand/bca.png">
                                </div>
                                <div class="icon-pay">
                                    <img src="images/brand/mandiri.png">
                                </div>
                            </div>
                        </div>
                        <div class="column-pay">
                            <p class="fo14 margin-top-no">Other</p>
                            <div class="box-pay-icon">
                                <div class="icon-pay">
                                    <img src="images/brand/gopay.png">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer5 padding-top-lg padding-bottom-lg">
                    <h4 class="cl-soft-pink margin-bottom-sm">Media Sosial</h4>
                    <ul class="sosmed">
                        <li><a href="#" class="cl-white"><img src="images/icons/xtwitter.svg" height="14"></a></li>
                        <li><a href="#" class="cl-white"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="cl-white"><i class="fa fa-instagram"></i></a></li>
                        <li><a href="#" class="cl-white"><i class="fa fa-youtube-play"></i></a></li>
                    </ul>
                </div>
                <div class="footer6 padding-top-lg padding-bottom-lg">
                    <p class="by cl-soft-pink">&copy; 2024 - Toyboxbali. Allright Reserved.</p>
                </div>
            </div>
        </div>
    </footer>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="js/main.js"></script>
    <script src="js/base.js"></script>
    <script src="js/slick.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.slider-utama').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: true,
                autoplay: true,
                dots: true,
                centerMode: true,
                infinite: true,
                centerPadding: '0',
                responsive: [{
                    breakpoint: 800,
                    settings: {
                        arrows: false,
                    }
                }]
            });
            $('.slider-small-banner').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: true,
                autoplay: true,
                dots: false,
                centerMode: true,
                infinite: true,
                centerPadding: '0',
                responsive: [{
                    breakpoint: 800,
                    settings: {}
                }]
            });
            $('.slider-kategori').slick({
                slidesToShow: 4,
                slidesToScroll: 1,
                arrows: true,
                autoplay: false,
                dots: false,
                centerMode: false,
                infinite: false,
                centerPadding: '0',
                variableWidth: true,
                responsive: [{
                    breakpoint: 800,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                    }
                }]
            });
            $('.slider-brand').slick({
                slidesToShow: 8,
                slidesToScroll: 8,
                arrows: true,
                autoplay: true,
                dots: false,
                centerMode: true,
                infinite: true,
                centerPadding: '0',
                responsive: [{
                    breakpoint: 900,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 4,
                    },
                    breakpoint: 640,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                    }
                }]
            });
            $('.slider-populer, .slider-stock').slick({
                slidesToShow: 5,
                slidesToScroll: 1,
                arrows: true,
                autoplay: true,
                dots: false,
                centerMode: true,
                infinite: true,
                centerPadding: '0',
                responsive: [{
                    breakpoint: 900,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        initialSlide: 3,
                    },
                    breakpoint: 640,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2,
                        initialSlide: 2,
                    }
                }]
            });
        });
    </script>
</body>

</html>