$('.box-search').hide();
$(document).ready(function() {
	$(".tabs-menu a").click(function(event) {
    	event.preventDefault();
        $(this).parent().addClass("current");
        $(this).parent().siblings().removeClass("current");
        var tab = $(this).attr("href");
        $(".tab-content").not(tab).css("display", "none");
        $(tab).fadeIn();
		$(".slider").slick('reinit');
    });
	$('.btn-ddr').on('click', function(e) {
            e.stopPropagation();
            var target = $(this).data('target');
            $('.ddr-menu').not(target).hide();
            $(target).fadeToggle();
        });
    $(document).on('click', function() {
            $('.ddr-menu').fadeOut('fast');
        });
    $('.btn-search').on('click', function(e) {
            e.stopPropagation();
            var srctarget = $(this).data('srctarget');
			$(this).find('i').toggleClass('fa-search fa-close');
            $(srctarget).fadeToggle();
            $('#cd-lateral-nav').removeClass('lateral-menu-is-open');
			$('#cd-menu-trigger').removeClass('is-clicked');
        });
});